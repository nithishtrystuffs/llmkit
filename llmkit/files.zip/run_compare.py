"""
Proves the adapter pattern works across providers: identical Client and
Message usage, only the adapter passed in changes.

Run from the project root (where pyproject.toml lives), with both keys set:

    export ANTHROPIC_API_KEY=sk-ant-...
    export OPENAI_API_KEY=sk-...
    python run_compare.py

On Windows (cmd):
    set ANTHROPIC_API_KEY=sk-ant-...
    set OPENAI_API_KEY=sk-...
    py run_compare.py
"""

import asyncio

from llmkit import Client, Message, Role
from llmkit.adapters.anthropic import AnthropicAdapter
from llmkit.adapters.openai import OpenAIAdapter

PROMPT = "Say hello in exactly 5 words."


async def run(label: str, client: Client, model: str) -> None:
    print(f"\n--- {label} ({model}) ---")
    resp = await client.generate(
        [Message.text(Role.USER, PROMPT)],
        model=model,
        max_tokens=50,
    )
    print("Text:       ", resp.text())
    print("Stop reason:", resp.stop_reason)
    print("Usage:      ", resp.usage)

    print(f"--- {label} streaming ---")
    stream_client = client
    async for chunk in stream_client.stream(
        [Message.text(Role.USER, PROMPT)], model=model, max_tokens=50
    ):
        if chunk.type == "text_delta":
            print(chunk.text, end="", flush=True)
    print()  # newline after stream


async def main() -> None:
    anthropic_client = Client(AnthropicAdapter())
    openai_client = Client(OpenAIAdapter())

    # Note: same `Client`, same `Message`, same call shape — only the
    # adapter instance and model string differ. This is the whole point.
    await run("Anthropic", anthropic_client, model="claude-sonnet-4-6")
    await run("OpenAI", openai_client, model="gpt-4o")


if __name__ == "__main__":
    asyncio.run(main())
